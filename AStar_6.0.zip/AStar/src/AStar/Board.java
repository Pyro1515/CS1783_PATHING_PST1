package AStar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aquat
 */
public class Board {
    int h,w;
    Node[][] board;
    public Board(int height, int width){
        System.out.println(height + "," + width);
        h = height;
        w = width;
        board = new Node[height][width];
    }
    
    public void emptyBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                board[i][j] = new Node(null, null);
            }
        }
    }
    
    public void loadMap(Data data){
        
    }
    
    public void update(int[][] barberInfo, int turnNumber){
        
    }
    
    public void changeSpace(char newVal, int x, int y){
            
        board[y - 1][x - 1].setSpace(newVal);
        
    }
    
    public void printBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                System.out.print(board[i][j].getSpace() + " ");
            }
            System.out.println();
        }
    }
    
}
