/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AStar;

/**
 *
 * @author Adam A
 */
public class Data {
    
    char[] spaceType;
    int[][] coords;
    public Data(char[] type, int[][] location){
        spaceType = new char[type.length];
        coords = new int[location.length][location[0].length];
        
        for(int i = 0; i < spaceType.length; i++){
            spaceType[i] = type[i];
            for(int j = 0; j < coords[0].length; j++){
                coords[i][j] = location[i][j];
            }
        }
    }
    
    public char getCharFor(int x, int y){
        
        return ' ';
    }
    
}
