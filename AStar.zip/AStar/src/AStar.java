
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * @author Chris
 * @author Adam
 */
public class AStar {
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        BoardInfo gameBoard = new BoardInfo();
        LoadData(gameBoard, "mapcup.txt");
        LoadData(gameBoard, "barbercup.txt");
        
    }
    
    
    public static void LoadData(BoardInfo gameBoard, String file){
        
    String fileName = file;
    
        try{
            Scanner fileScan = new Scanner(new File(fileName));
            ArrayList<String> data = new ArrayList<>();
            while(fileScan.hasNextLine()){
                if(fileScan.nextLine().length() > 1){
                    data.add(fileScan.nextLine());
                }
            }
            
            char temp = data.get(0).charAt(0);
            
            if(Character.isDigit(temp)){
                int[][] barbers = new int[data.size()][3];
                for(int i = 0; i < data.size(); i++){
                    String[] col = data.get(i).split(" ");
                    
                    barbers[i][0] = Integer.parseInt(col[0]);
                    barbers[i][1] = Integer.parseInt(col[1]);
                    barbers[i][2] = Integer.parseInt(col[2]);
                }
                gameBoard.setBarberData(barbers);
            }else{
                char[] spaceType = new char[data.size()];
                int[][] spaceLocation = new int[data.size()][2];
                
                for(int i = 0; i < data.size(); i++){
                    String[] col = data.get(i).split(" ");
                    
                    spaceType[i] = col[0].charAt(0);
                    spaceLocation[i][0] = Integer.parseInt(col[1]);
                    spaceLocation[i][1] = Integer.parseInt(col[2]);
                    
                }
            }
            
            
        }
        catch(FileNotFoundException e){
            System.out.println("File: " + fileName + "could not be found.");
        }
    
    }
}
