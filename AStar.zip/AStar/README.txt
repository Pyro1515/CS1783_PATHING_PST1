# CS1783_PATHING_PST1

/*
To Run AStar

open CMD or Terminal

go to //.. \AStar\

Enter in CMD

javac *.java

jar -cvfm AStar.jar manifest.txt AStar\*.class AStar\*.txt

java -jar "AStar.jar"

Prompt for Folder

C:\Users\Chris\Desktop\AStar\AStar\

program will finish running


*/