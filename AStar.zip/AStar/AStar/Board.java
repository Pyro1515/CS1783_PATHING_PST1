package AStar;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 * @author Zach
 * @author Chris
 * @author Adam
 */
public class Board {
    int h,w;
    Node[][] board;
    Data data;
    
    //board constructor, gets map dimmensions, map space info, 
    //and special space location data (walls, start, goal locations)
    public Board(int height, int width, char[] temp1, int[][] temp2){
        System.out.println(height + "," + width);
        h = height;
        w = width;
        board = new Node[height][width];
        data = new Data(temp1, temp2);
    }
    
    //return map dimmensions in an array
    public int[] getMapDimmension(){
        int[] temp = new int[2];
        temp[0] = h;
        temp[1] = w;
        return temp;
    }
    
    //load all nodes with a ' ' char and their locations data
    public void emptyBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                board[i][j] = new Node(null, i, j);
            }
        }
    }
    
    //reads through map location array and places walls, S,
    public void loadMap(){    
        int[][] coords;
        coords = data.getLocationArray();
        
        //start at 1 so the map dimmensions arent included
        for(int i = 1; i < coords.length; i++){
           //get character from Data class, and pass the character into the change space method
           //along with its new coordinates.
           this.changeSpace((data.getCharFor(coords[i][0], coords[i][1])), coords[i][0], coords[i][1]);
        }
        
    }
    
    //update barber locations
    public void update(int[][] barberInfo, int turnNumber){
        
        //this entire if block contains a way to remove barbers from their old location
        if(turnNumber > 0){
            for(int i = 1; i <barberInfo.length; i++){
                if(barberInfo[i][0] == turnNumber - 1){
                    char temp = data.getCharFor(barberInfo[i][1], barberInfo[i][2]);
                    if(temp == 'B'){
                        this.changeSpace(' ', barberInfo[i][1], barberInfo[i][2]);
                    }
                }
            }
        }
        
        //this block reinserts barbers onto the map
        for(int i = 0; i < barberInfo.length; i++){
            if(barberInfo[i][0] == turnNumber){
                char temp = data.getCharFor(barberInfo[i][1], barberInfo[i][2]);
                if( temp == ' '){
                    this.changeSpace('B', barberInfo[i][1], barberInfo[i][2]);
                }
            }
        }
    }
    
    //change the char value stored in a specified node
    public void changeSpace(char newVal, int row, int column){
            
        board[row][column].setSpaceType(newVal);
        
    }
    
    //returns a char stored in a node at a specified location
    public char getSpace(int row, int column){
        return board[row][column].getSpaceType();
    }
    
    //prints
    public void printBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                System.out.print('[');
                System.out.print(board[i][j].getSpaceType());
                System.out.print(']');
            }
            System.out.println();
        }
    }
    
    //check to see if the space would be a valid move
    public boolean isWalkable(int row, int column){
        
        //if row number has ArrayOutOfBounds error return false
        if(row < 0 || row >= h){
            return false;
        }
        
        //if column number has ArrayOutOfBounds error return false
        if(column < 0 || column >= w){
            return false;
        }
        
        //if character at index on map is wall, return false
        if(board[row][column].getSpaceType() == 'W' || board[row][column].getSpaceType() == 'B'){
            return false;
        }
        
        //none of those then it can be used. return true
        return true;
    }
    
    //A* search method
    public boolean search(){
        
        //Start and End Node coords
        int start_i, start_j, end_i, end_j; 
        
        boolean status = true;
                
        //2d int array with map data
        int[][] temp = data.getLocationArray();
        
        //grab the start and end data
        start_i = temp[1][0];
        start_j = temp[1][1];
        end_i = temp[2][0];
        end_j = temp[2][1];
        
        //Create Node for navigation of lists and board
        Node start = board[start_i][start_j];
        Node goal = board[end_i][end_j];
        Node current = start;
        Node bestChild;
        
        //search the board for the start space and set current to that node
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                if(board[i][j].getSpaceType() == 'S'){
                    current = board[i][j];
                }
            }
        }
        
        //create open and closed list
        ArrayList<Node> openList = new ArrayList<>();
        ArrayList<Node> closedList = new ArrayList<>();
        
        //set the current node's heuristic data
        current.setH(heuristic(current, goal));
        
        //set the f value, total cost
        current.setF(current.getH() + current.getG());
        
        //add the start node to the openList
        openList.add(start);
        
        //while the open list is not empty do the following
        while(!openList.isEmpty()){
            
            //if the current node is the goal node, add it to the closed list
            //and break out of the while loop
            if(current.equals(goal)){
                status = false;
                closedList.add(current);
                break;
            }
            
            //just some temp variables
            int temp1, temp2;
            Node tempNode;
            
            //get the adjacent space above
            temp1 = current.getRow() - 1;
            temp2 = current.getColumn();
            
            if(isWalkable(temp1, temp2) && !closedList.contains(board[temp1][temp2])){
                tempNode = board[temp1][temp2];
                tempNode.setParent(current);
                tempNode.setG(current.getG() + 1);
                tempNode.setF(heuristic(tempNode, goal) + tempNode.getG());
                openList.add(tempNode);
            }
            
            temp1 = current.getRow();
            temp2 = current.getColumn() + 1;
            //get adjacent space to the right
            if(isWalkable(temp1, temp2) && !closedList.contains(board[temp1][temp2])){
                tempNode = board[temp1][temp2];
                tempNode.setParent(current);
                tempNode.setG(current.getG() + 1);
                tempNode.setF(heuristic(tempNode, goal) + tempNode.getG());
                openList.add(tempNode);
            }
            
            temp1 = current.getRow() + 1;
            temp2 = current.getColumn();
            //get adjacent space below
            if(isWalkable(temp1, temp2) && !closedList.contains(board[temp1][temp2])){
                tempNode = board[temp1][temp2];
                tempNode.setParent(current);
                tempNode.setG(current.getG() + 1);
                tempNode.setF(heuristic(tempNode, goal) + tempNode.getG());
                openList.add(tempNode);
            }
            
            temp1 = current.getRow();
            temp2 = current.getColumn() - 1;
            //get adjacent space to the left
            if(isWalkable(temp1, temp2) && !closedList.contains(board[temp1][temp2])){
                tempNode = board[temp1][temp2];
                tempNode.setParent(current);
                tempNode.setG(current.getG() + 1);
                tempNode.setF(heuristic(tempNode, goal) + tempNode.getG());
                openList.add(tempNode); //to the left
            }
            
            //start searching for the best child at the first item in the open list
            bestChild = openList.get(0);
            
            //compare all items to find the smallest f value in the open list
            for(int i = 0; i < openList.size() - 1; i++){
                if(bestChild.compareF(bestChild, openList.get(i))){
                    bestChild = openList.get(i);
                }
            }
            
            //move the smallest f value node to the closed list
            closedList.add(bestChild);
            
            //change the current node to the new entry in closed
            current = bestChild;
            
            //remove the item from the open list
            openList.remove(bestChild);

        }
        
        //call refresh
        refreshPath(closedList);
        
        return status;
    }

    //finds heuristic value of a current node
    public double heuristic(Node current, Node goal){
        double heuristic, currentVal, goalVal;
        
        currentVal = (double)current.getRow();
        goalVal = (double)goal.getRow();
        
        heuristic = Math.pow(goalVal - currentVal, 2);
        
        currentVal = (double)current.getColumn();
        goalVal = (double)goal.getColumn();

        heuristic += Math.pow(goalVal - currentVal, 2);
         

        return heuristic;
    }
    
    //refreshes spaces on the board to show path
    private void refreshPath(ArrayList<Node> bestPath){
        
        //removes the S from its last location
        bestPath.get(0).setSpaceType(' ');
        
        //puts S in new location
        bestPath.get(1).setSpaceType('S');
        
        //puts * at every point in the closed list
        for(int i = 0; i < bestPath.size(); i++){
            if(bestPath.get(i).getSpaceType() != 'S' && bestPath.get(i).getSpaceType() != 'B' 
                    && bestPath.get(i).getSpaceType() != 'W' && bestPath.get(i).getSpaceType() != 'G' ){
                bestPath.get(i).setSpaceType('*');
            }
            
        
        }
    }
}
