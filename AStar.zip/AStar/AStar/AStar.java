package AStar;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

// * @author Chris
// * @author Adam
// * @author Zach


public class AStar {
    /**
     * 
     * @throws java.io.IOException
     */
    
    private static Scanner input = new Scanner(System.in);
    
    public static void main(String[] args) throws IOException {
        
        boolean status = true;
        int turnCount = 0;
        System.out.println("Enter Program Folder Path:");
        
        String path = input.nextLine();
        
        //read in Map Data
        //map is Board is constructed and returned as well
        Board gameBoard = LoadMapData(path + "mapcup.txt");
        
        //read in barber data
        int[][] barberInfo = LoadBarbData(path + "barbercup.txt");

        //loads empty spaces into all nodes on the board
        gameBoard.emptyBoard();
        
        //loads map info such as start, goals, and walls into appropriate locations
        gameBoard.loadMap();
        
        gameBoard.printBoard();
        
        // run the game?
        while(turnCount < barberInfo.length){
            
            System.out.println();
            System.out.println("============================");
            System.out.println();
            gameBoard.update(barberInfo, turnCount);
            gameBoard.search();
            turnCount++;
            gameBoard.printBoard();
        }
        
        //New map and barber files to play with
        System.out.println("END GAME 1");
        System.out.println("============================");
        System.out.println("GAME 2");
        Board gameBoard1 = LoadMapData(path + "mapgoaraound.txt");
        int[][] barberInfo1 = LoadBarbData(path + "barbergoaround.txt");
        turnCount = 0;
        gameBoard1.emptyBoard();
        gameBoard1.loadMap();
        gameBoard1.printBoard();
        
        while(turnCount < barberInfo1.length){
            System.out.println();
            System.out.println("============================");
            System.out.println();
            gameBoard1.update(barberInfo1, turnCount);
            gameBoard1.search();
            turnCount++;
            gameBoard1.printBoard();
        }
        
        //New map and barber files to play with
        System.out.println("END GAME 2");
        System.out.println("============================");
        System.out.println("GAME 3");
        Board gameBoard2 = LoadMapData(path + "mapgoaraoundfake.txt");
        int[][] barberInfo2 = LoadBarbData(path + "barbergoaroundfake.txt");
        turnCount = 0;
        gameBoard2.emptyBoard();
        gameBoard2.loadMap();
        gameBoard2.printBoard();
        
        while(turnCount < barberInfo2.length){
            System.out.println();
            System.out.println("============================");
            System.out.println();
            gameBoard2.update(barberInfo2, turnCount);
            gameBoard2.search();
            turnCount++;
            gameBoard2.printBoard();
        }
    }
    
    //read in map data from map txt files
    public static Board LoadMapData(String file) throws IOException {

        BufferedReader inputStream = null;
        System.out.println(file);
        ArrayList<String> data = new ArrayList<>();

        try {
            inputStream = new BufferedReader(new FileReader(file));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                data.add(temp);
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        //check to make sure file is a map file
        if(file.contains("map")){

            char[] spaceType = new char[data.size() - 1];
            int[][] spaceLocation = new int[data.size() - 1][2];
            for(int i = 0; i < (data.size() - 1); i++)
            {
                String[] col = data.get(i).split(" ");
                
                spaceType[i] = col[0].charAt(0);
                
                spaceLocation[i][0] = Integer.parseInt(col[1]);
                spaceLocation[i][1] = Integer.parseInt(col[2]);
            }
            
            //call board constructor with read in map data
            Board gameBoard = new Board(spaceLocation[0][0], spaceLocation[0][1], spaceType, spaceLocation);
            
            //return map data
            return gameBoard;  
        }
        return null;
    }
    
    //read in barber data
    public static int[][] LoadBarbData(String file) throws IOException {

        BufferedReader inputStream = null;
        System.out.println(file);
        ArrayList<String> data = new ArrayList<>();

        try {
            inputStream = new BufferedReader(new FileReader(file));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                data.add(temp);
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        
        //check to make sure file is a barber info file
        if(file.contains("barb")){
            
            int[][] barbers = new int[data.size() - 1][3];
            for(int i = 0; i < (data.size() - 1); i++){
                String[] col = data.get(i).split(" ");
                
                barbers[i][0] = Integer.parseInt(col[0]);
                barbers[i][1] = Integer.parseInt(col[1]);
                barbers[i][2] = Integer.parseInt(col[2]);
            }
            
            //return 2D array of barber info
            return barbers;
        }
       return null;
    }
    
    

}