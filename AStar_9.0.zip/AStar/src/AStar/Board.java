package AStar;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aquat
 */
public class Board {
    int h,w;
    Node[][] board;
    Data data;
    public Board(int height, int width, char[] temp1, int[][] temp2){
        System.out.println(height + "," + width);
        h = height;
        w = width;
        board = new Node[height][width];
        data = new Data(temp1, temp2);
    }
    
    public int[] getMapDimmension(){
        int[] temp = new int[2];
        temp[0] = h;
        temp[1] = w;
        return temp;
    }
    
    public void emptyBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                board[i][j] = new Node(null, i, j);
            }
        }
    }
    
    public void loadMap(){
        
        int[][] coords;
        coords = data.getLocationArray();
        
        for(int i = 1; i < coords.length; i++){
           this.changeSpace((data.getCharFor(coords[i][0], coords[i][1])), coords[i][0], coords[i][1]);
           //System.out.println(coords[i][0]);
        }
        
    }
    
    public void update(int[][] barberInfo, int turnNumber){
        for(int i = 0; i < barberInfo.length; i++){
            if(barberInfo[i][0] == turnNumber){
                char temp = data.getCharFor(barberInfo[i][1], barberInfo[i][2]);
                if( temp == ' '){
                    this.changeSpace('B', barberInfo[i][1], barberInfo[i][2]);
                }
            }
        }
    }
    
    public void changeSpace(char newVal, int row, int column){
            
        board[row][column].setSpace(newVal);
        
    }
    
    
    public char getSpace(int row, int column){
        return board[row][column].getSpace();
    }
    
    public void printBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                System.out.print('[');
                System.out.print(board[i][j].getSpace());
                System.out.print(']');
            }
            System.out.println();
        }
    }
    
    public ArrayList<Node> search(Board gameBoard){
        int height = gameBoard.getMapDimmension()[0];
        int width = gameBoard.getMapDimmension()[1];
        int row, column;
        
        ArrayList<Node> openList = new ArrayList<Node>();
        ArrayList<Node> closedList = new ArrayList<Node>();
        
        for(int i = 0; i < height; i++){
            for(int j = 0; j < width; j++){
                if(gameBoard.getSpace(i, j) == 'S'){
                    closedList.add(board[i][j]); 
                }
            }
        }
        row = closedList.get(0).getRow();
        column = closedList.get(0).getColumn();
        
        
        openList.add(board[row-1][column]); //above
        openList.add(board[row][column+1]); //to the right
        openList.add(board[row+1][column]); //below
        openList.add(board[row][column-1]);  //to the left
        
        return openList;
    }
    
}
