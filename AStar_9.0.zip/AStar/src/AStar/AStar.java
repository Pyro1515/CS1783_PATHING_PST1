package AStar;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;

// * @author Chris
// * @author Adam

/*
       ||||||||||       ||||||||||||         //\\           ||||||||||
       ||       ||      ||                  //  \\          ||      |||
       ||       ||      ||                 //    \\         ||        ||
       ||      //       ||||||||||||      //||||||\\        ||         ||
       ||     \\        ||               //        \\       ||        ||
       ||      \\       ||              //          \\      ||      |||
       ||       \\      ||||||||||||   //            \\     ||||||||||        
*/

/*
*   CHANGES MADE: 
*   REMOVED BOARD INFO CLASS
*   TAKEN READ IN DATA AND SPLIT INTO INT AND CHAR ARRAYS (MAYBE NOT THE BEST SOLUTION)
 */

/*
*   To do:
*   Load board data and get the first line to create board with proper size.
*   Board will need to be an array of Nodes.
*   Create a Node class that has f,g,h, and character for each space as variables.
*   Create Board as with Nodes that have all default values.
*   Mode Class should have getters and setters for all things.
*   Load board data and set special case spaces (smigla, barbers, walls, start, goal)
*       using x,y values insteat of checking every space as board is populated, just check
*       the locations known, and replace.
*   Figure out how to store MapInfo data, and BarberInfo data while loading.
*/

public class AStar {
    /**
     * 
     * @throws java.io.IOException
     */
    
    private static Scanner input = new Scanner(System.in);
    
    public static void main(String[] args) throws IOException {
        
        int turnCount = 0;
        System.out.println("Enter Program Folder Path:");
        
        String path = input.nextLine();
        
        
        Board gameBoard = LoadMapData(path + "mapcup.txt");
        int[][] barberInfo = LoadBarbData(path + "barbergoaround.txt");
        
        gameBoard.emptyBoard();
        gameBoard.loadMap();
        gameBoard.printBoard();
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.update(barberInfo, turnCount);
        turnCount++;
        gameBoard.printBoard();
        
// just testing through multiple turns cause i didnt want to write a simple loop, cause im retarded.
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();

        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
        
                turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();

        
        turnCount++;
        gameBoard.update(barberInfo, turnCount);
        System.out.println();
        System.out.println("============================");
        System.out.println();
        gameBoard.printBoard();
    }
    
    
    public static Board LoadMapData(String file) throws IOException {

        BufferedReader inputStream = null;
        System.out.println(file);
        ArrayList<String> data = new ArrayList<>();

        try {
            inputStream = new BufferedReader(new FileReader(file));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                data.add(temp);
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        
        if(file.contains("map")){

            char[] spaceType = new char[data.size() - 1];
            int[][] spaceLocation = new int[data.size() - 1][2];
            for(int i = 0; i < (data.size() - 1); i++)
            {
                String[] col = data.get(i).split(" ");
                
                spaceType[i] = col[0].charAt(0);
                
                spaceLocation[i][0] = Integer.parseInt(col[1]);
                spaceLocation[i][1] = Integer.parseInt(col[2]);
            }
            Board gameBoard = new Board(spaceLocation[0][0], spaceLocation[0][1], spaceType, spaceLocation);
            return gameBoard;  
        }
        return null;
    }
    
    public static int[][] LoadBarbData(String file) throws IOException {

        BufferedReader inputStream = null;
        System.out.println(file);
        ArrayList<String> data = new ArrayList<>();

        try {
            inputStream = new BufferedReader(new FileReader(file));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                data.add(temp);
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        
        if(file.contains("barb")){
            
            int[][] barbers = new int[data.size() - 1][3];
            for(int i = 0; i < (data.size() - 1); i++){
                String[] col = data.get(i).split(" ");
                
                barbers[i][0] = Integer.parseInt(col[0]);
                barbers[i][1] = Integer.parseInt(col[1]);
                barbers[i][2] = Integer.parseInt(col[2]);
            }
            return barbers;
        }
       return null;
    }
    
    

}