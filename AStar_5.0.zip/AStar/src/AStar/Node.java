/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AStar;

/**
 *
 * @author Adam A
 */

public class Node {
    
    Node current, prev;
    char spaceType;
    double f,g,h;
    
    public Node(Node parent, Node next){
        this.f = this.g = this.h = 0;
        prev = parent;
        current = next;
    }
    
    public void setSpace(){
        
    }
}
