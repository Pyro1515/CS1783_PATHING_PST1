/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AStar;

/**
 *
 * @author Adam A
 */
public class Data {
    public Data(int[][] var){
        int[][] barbers = new int[var.length][var[0].length];
        
        for(int i = 0; i < barbers.length; i++){
            for(int j = 0; j < barbers[0].length; j++){
                barbers[i][j] = var[i][j];
            }
        }
    }
    
    public Data(char[] type, int[][] location){
        char[] spaceType = new char[type.length];
        int[][] coords = new int[location.length][location[0].length];
        
        for(int i = 0; i < spaceType.length; i++){
            spaceType[i] = type[i];
            for(int j = 0; j < coords[0].length; j++){
                coords[i][j] = location[i][j];
            }
        }
    }
    
}
