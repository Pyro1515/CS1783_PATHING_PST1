package AStar;

import java.util.ArrayList;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aquat
 */
public class Board {
    int h,w;
    Node[][] board;
    Data data;
    public Board(int height, int width, char[] temp1, int[][] temp2){
        System.out.println(height + "," + width);
        h = height;
        w = width;
        board = new Node[height][width];
        data = new Data(temp1, temp2);
    }
    
    public int[] getMapDimmension(){
        int[] temp = new int[2];
        temp[0] = h;
        temp[1] = w;
        return temp;
    }
    
    public void emptyBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                board[i][j] = new Node(null, i, j);
            }
        }
    }
    
    public void loadMap(){
        
        int[][] coords;
        coords = data.getLocationArray();
        
        for(int i = 1; i < coords.length; i++){
           this.changeSpace((data.getCharFor(coords[i][0], coords[i][1])), coords[i][0], coords[i][1]);
           //System.out.println(coords[i][0]);
        }
        
    }
    
    public void update(int[][] barberInfo, int turnNumber){
        
        if(turnNumber > 0){
            for(int i = 1; i <barberInfo.length; i++){
                if(barberInfo[i][0] == turnNumber - 1){
                    char temp = data.getCharFor(barberInfo[i][1], barberInfo[i][2]);
                    if(temp == 'B'){
                        this.changeSpace(' ', barberInfo[i][1], barberInfo[i][2]);
                    }
                }
            }
        }
        
        for(int i = 0; i < barberInfo.length; i++){
            if(barberInfo[i][0] == turnNumber){
                char temp = data.getCharFor(barberInfo[i][1], barberInfo[i][2]);
                if( temp == ' '){
                    this.changeSpace('B', barberInfo[i][1], barberInfo[i][2]);
                }
            }
        }
    }
    
    public void changeSpace(char newVal, int row, int column){
            
        board[row][column].setSpaceType(newVal);
        
    }
    
    
    public char getSpace(int row, int column){
        return board[row][column].getSpaceType();
    }
    
    public void printBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                System.out.print('[');
                System.out.print(board[i][j].getSpaceType());
                System.out.print(']');
            }
            System.out.println();
        }
    }
    
    public boolean isWalkable(int row, int column){
        
        //if row number has ArrayOutOfBounds error return false
        if(row < 0 || row >= h){
            return false;
        }
        
        //if column number has ArrayOutOfBounds error return false
        if(column < 0 && column >= w){
            return false;
        }
        
        //if character at index on map is wall, return false
        if(board[row][column].getSpaceType() == 'W'){
            return false;
        }
        
        //none of those then it can be used. return true
        return true;
    }
    
    public ArrayList<Node> search(Board gameBoard){
        int height = gameBoard.getMapDimmension()[0];
        int width = gameBoard.getMapDimmension()[1];
        int row, column;
        int start_i, start_j, end_i, end_j;
                
        int[][] temp = data.getLocationArray();
        
        start_i = temp[1][0];
        start_j = temp[1][1];
        end_i = temp[temp.length][0];
        end_j = temp[temp.length][1];
        
        Node start = board[start_i][start_j];
        Node goal = board[end_i][end_j];
        Node current = start;
        
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                if(board[i][j].getSpaceType() == 'S'){
                    current = board[i][j];
                }
            }
        }
        
        ArrayList<Node> openList = new ArrayList<>();
        ArrayList<Node> closedList = new ArrayList<>();
        
        current.setH(heuristic(current, goal));
        current.setF(current.getH() + current.getG());
        
        openList.add(start);
        
        while(!openList.isEmpty()){
            
        }
        
        
        
        row = closedList.get(0).getRow();    
        column = closedList.get(0).getColumn();
        
        
        openList.add(board[row-1][column]); //above
        openList.add(board[row][column+1]); //to the right
        openList.add(board[row+1][column]); //below
        openList.add(board[row][column-1]);  //to the left
        
        return openList;
    }

    public double heuristic(Node current, Node goal){
        double heuristic, currentVal, goalVal;
        
        currentVal = (double)current.getRow();
        goalVal = (double)goal.getRow();
        
        heuristic = Math.pow(goalVal - currentVal, 2);
        
        currentVal = (double)current.getColumn();
        goalVal = (double)goal.getColumn();
        
        heuristic += Math.pow(goalVal - currentVal, 2);
         
        return heuristic;
    }
}
