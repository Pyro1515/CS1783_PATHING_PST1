package AStar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aquat
 */
public class BoardInfo {
    
    String info;
    int object = -1;
    private char[] spaceType;
    private int[][] barberInfo;
    private int[][] spaceLocation;
    
    public BoardInfo(){

    }
    
    public void setBarberData(int[][] temp){
        object = 0;
        info = "Array |Moves made|Barber x Coord|Barber y Coord|";
        barberInfo = new int[temp.length][3];
        
        for(int i = 0; i < temp.length; i++){
            for(int j = 0; j < 3; j++){
                barberInfo[i][j] = temp[i][j];
            }
        }
    }
    
    public void setSpaceData(char[] type, int[][] coords){
        object = 1;
        info = "charArray with spaceType and 2d int array with space x and y coords.";
        
        for(int i = 0; i < type.length; i++){
            spaceType[i] = type[i];
        }
        
        for(int i = 0; i < coords.length; i++){
            for(int j = 0; j < 2; j++){
                spaceLocation[i][j] = coords[i][j];
            }
        }
    }
    
    public char getSpaceType(int turn, int row, int column){
        if(object == 0){
            for(int i = 0; i < barberInfo.length; i++){
                if(barberInfo[i][0] == turn && barberInfo[i][1] == row && barberInfo[i][2] == column){
                    return 'B';
                }
            }
        }
        if(object == 1){
            for(int i = 0; i < spaceLocation.length; i++){
                if(spaceLocation[i][0] == row && spaceLocation[i][1] == column){
                    return spaceType[row];
                }
            }
            return ' '; 
        }else{
            return 'Z';
        }
    }
}
