package AStar;

import java.io.*;
import java.util.ArrayList;
import java.util.Scanner;


/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 *
 * @author Chris
 * @author Adam
 */

public class AStar {
    /**
     * 
     * @throws java.io.IOException
     */
    
    public static Scanner input = new Scanner(System.in);
    
    public static void main(String[] args) throws IOException {
        
        BoardInfo gameBoard = new BoardInfo();
        System.out.println("Enter Program Folder Path:");
        
        String path = input.nextLine();
        
        LoadData(gameBoard, path + "mapcup.txt");
        LoadData(gameBoard, path + "barbercup.txt");
        
    }
    
    



    public static void LoadData(BoardInfo gameBoard, String file) throws IOException {

        BufferedReader inputStream = null;
        System.out.println(file);
        ArrayList<String> data = new ArrayList<>();

        try {
            inputStream = new BufferedReader(new FileReader(file));
            

            String temp;
            while ((temp = inputStream.readLine()) != null) {
                data.add(temp);
            }
        } finally {
            if (inputStream != null) {
                inputStream.close();
            }
        }
        
        for(int i = 0; i < data.size(); i++)
        {
        System.out.println(data.get(i));
        }
    }

}
