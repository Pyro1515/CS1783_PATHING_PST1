/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package AStar;

/**
 *
 * @author Adam A
 */

public class Node {
    
    private Node parent;
    private char spaceType;
    private double f,g,h;
    private int row, column;
    
    public Node(Node prev, int i, int j){
        this.f = this.g = this.h = 0;
        spaceType = ' ';
        parent = prev;
        int row = i;
        int column = j;
    }
    
    public void setF(double value){
        this.f = value;
    }
    
    public double getF(){
        return this.f;
    }

    public Node getParent() {
        return parent;
    }

    public void setParent(Node prev) {
        this.parent = prev;
    }

    public char getSpaceType() {
        return spaceType;
    }

    public void setSpaceType(char spaceType) {
        this.spaceType = spaceType;
    }

    public double getG() {
        return g;
    }

    public void setG(double g) {
        this.g = g;
    }

    public double getH() {
        return h;
    }

    public void setH(double h) {
        this.h = h;
    }
    
    public int getRow(){
        return row;
    }
    
    public int getColumn(){
        return column;
    }
    
    public boolean compare(Node one, Node two){
        return one.getF() < two.getF();
    }
    
    
}
