package AStar;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author aquat
 */
public class Board {
    int h,w;
    Node[][] board;
    Data data;
    public Board(int height, int width, char[] temp1, int[][] temp2){
        System.out.println(height + "," + width);
        h = height;
        w = width;
        board = new Node[height][width];
        data = new Data(temp1, temp2);
    }
    
    public void emptyBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                board[i][j] = new Node(null, null);
            }
        }
    }
    
    public void loadMap(){
        
        int[][] coords;
        coords = data.getLocationArray();
        
        for(int i = 1; i < coords.length; i++){
           this.changeSpace((data.getCharFor(coords[i][0], coords[i][1])), coords[i][0], coords[i][1]);
           //System.out.println(coords[i][0]);
        }
        
    }
    
    public void update(int[][] barberInfo, int turnNumber){
        for(int i = 0; i < barberInfo.length; i++){
            if(barberInfo[i][0] == turnNumber){
                char temp = data.getCharFor(barberInfo[i][1], barberInfo[i][2]);
                if( temp == ' '){
                    this.changeSpace('B', barberInfo[i][1], barberInfo[i][2]);
                }
            }
        }
    }
    
    public void changeSpace(char newVal, int row, int column){
            
        board[row][column].setSpace(newVal);
        
    }
    
    public void printBoard(){
        for(int i = 0; i < h; i++){
            for(int j = 0; j < w; j++){
                System.out.print('[');
                System.out.print(board[i][j].getSpace());
                System.out.print(']');
            }
            System.out.println();
        }
    }
    
}
